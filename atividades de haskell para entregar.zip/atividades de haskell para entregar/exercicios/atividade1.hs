type Doc = String
type Line = String
type Palavra = String
type Letra = Char
--makeindex:: Doc ->  [(Int,Word)]

--lines2 :: Doc -> [Line]
--lines2 [e] = [[e]]
--lines2 (a:b) = [[a]] ++ lines2 b

--lines3 :: Doc -> [Line]
--lines3 [e] = [[e]]
--lines3 (a:b) 
--  |[a] == " " = [[a]] ++ lines3 b
--  |otherwise = [[[a]] ++ lines3 (b)]

--item 1
lines2 :: Doc -> [Line]
lines2 [] = []
lines2 documento = separarEmLinhas documento : lines2 (pegaResto documento)

separarEmLinhas :: Doc -> Line
separarEmLinhas[] = []
separarEmLinhas (a:b)
 |a /= '\n' = a:(separarEmLinhas b) 
 |otherwise = []

pegaResto :: Doc -> Doc
pegaResto [] = []
pegaResto (a:b) 
  |a /= '\n' = pegaResto b
  |otherwise = b
--fim item 1

--separar em espaços
--lines3 :: Doc -> [Line]
--lines3 documento = words documento

--item 2
numLines2 :: [Line] -> [(Int,Line)]
numLines2 linhas = numeraLinha linhas 1

numeraLinha :: [Line] -> Int -> [(Int,Line)]
numeraLinha[e] x = [(x,e)]
numeraLinha (a:b) x = [(x,a)] ++ numeraLinha b (x+1)
--fim item2

doc :: Doc
doc = "Eu tenho sim, " ++
      "um sonho sim\n" ++
      "Que as lanternas flutuantes " ++
      "sao pra mim!"

--item 3
allNumWords :: [(Int,Line)] -> [(Int,Line)]
allNumWords [] = []
allNumWords ((a,b):c)
  |b /= [] && pegaAteEspaco b /= "espaco" = (a,pegaAteEspaco b) : allNumWords ((a,pegaRestoString b) : c)
  |pegaAteEspaco b == "espaco" = allNumWords ((a,pegaRestoString b) : c)
  |otherwise = allNumWords c

pegaAteEspaco :: Line -> Line
pegaAteEspaco[] = []
pegaAteEspaco (a:b) 
  |a /= ' ' && pegaAteEspaco b /= "espaco" = a : pegaAteEspaco b
  |pegaAteEspaco b == "espaco" = [a]
  |otherwise = "espaco"

pegaRestoString :: Line -> Line
pegaRestoString [] = []
pegaRestoString (a:b)
  |a /= ' ' = pegaRestoString b
  |otherwise = b
--fim item 3

--item 4
-- ordenacao por insercao
sortLs:: [(Int,Palavra)] -> [(Int,Palavra)]
sortLs lista = [x] ++ sortLs(remove x lista)
                      where x = minimo lista

remove :: (Int,Palavra) -> [(Int,Palavra)] -> [(Int,Palavra)]
remove (a,b) [] = []
remove (a,s1) ((b,s2):r)
  |s1 == s2 = r
  |otherwise = (b,s2) : remove (a,s1) r

minimo :: [(Int,Palavra)] -> (Int,Palavra)
minimo[] = undefined
minimo[e] = e
minimo((a,(s1:sf)):r)
  |s1 <= pegaString(minimo r) = (a,(s1:sf))
  |otherwise = minimo r 

pegaString :: (Int,Palavra) -> Letra
pegaString(num,(s1:sf)) = s1
--fim item 4

--item5
makeLists :: [(Int,Palavra)] -> [([Int],Palavra)]
makeLists[] = []
makeLists((num,palavra):resto) = ([num],palavra): makeLists resto
--fim item5

teste:: Doc
teste = "eu \n eu gosto \n gosto de \n de"

--item6
almalgamate :: [([Int],Palavra)] -> [([Int],Palavra)]
almalgamate[e] = [e]
almalgamate ((num,palavra):(num2,palavra2):r) --((num,palavra):(num2,palavra2):r) = (num,palavra):[(num2,palavra2)] 
  |palavra == palavra2 = almalgamate ((num ++ num2,palavra):r)
  |otherwise = (num,palavra) : almalgamate ((num2,palavra2):r)
--fim item6

--segundoItem :: [([Int],Palavra)] -> Palavra
-- segundoItem((_,palavra):r) = palavra


--doc2 = lines2 doc
--doc3 = numLines2 doc2
--doc4 = allNumWords doc3
--doc5 = sortLs doc4
--doc6 = makeLists doc5
--doc7 = almalgamate doc6